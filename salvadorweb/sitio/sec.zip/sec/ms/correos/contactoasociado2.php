        </table>
      </center>
    </td>
  </tr>
    <tr>
    <td align="center" valign="top" width="100%" style="background-color: #f7f7f7; height: 100px;">
      <center>
        <table cellspacing="0" cellpadding="0" width="600" class="w320">
          <tr>
            <td style="padding: 25px 0 25px">
              <strong>Salvador Hairdressing</strong><br />
              Formulario de Contacto para los Asociados <br />
              <i>La información contenida en este correo es confidencial.</i> <br /><br />
            </td>
          </tr>
        </table>
      </center>
    </td>
  </tr>
</table>
</body>
</html>